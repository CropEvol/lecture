# pwd,cd,cat,mkdir,mvコマンド練習用

basedir=`echo ${PWD##*/}`
echo "I am in ${basedir}." > "./iamin.txt"

for p in {1..5};do
    mkdir -p "dir${p}"
    echo "I am in ${basedir}/dir${p}." > "./dir${p}/iamin.txt"

    for q in {1..3};do
        mkdir -p "dir${p}/subdir${q}"
        echo "I am in ${basedir}/dir${p}/subdir${q}." > "./dir${p}/subdir${q}/iamin.txt"

        for r in {1..2};do
            mkdir -p "dir${p}/subdir${q}/subusubdir${r}"
            echo "I am in ${basedir}/dir${p}/subdir${q}/subusubdir${r}." > "./dir${p}/subdir${q}/subusubdir${r}/iamin.txt"
        done
    done
done

# --------------
# cat,less,grepコマンド練習用

dirname='seqdir'
mkdir -p ${dirname}
for i in {1..3};do
    touch "${dirname}/randseq${i}.fasta"
    for j in {1..4};do
        echo ">randseq${i}_${j}" >> "${dirname}/randseq${i}.fasta"
        cat /dev/urandom | LC_CTYPE=C tr -dc ATGC | fold -w 60 | head -n 100 >> "${dirname}/randseq${i}.fasta"
    done
done

# --------------
# ls,grepコマンド練習用

dirname='txtdir'
mkdir -p ${dirname}
for i in `seq -w 10`;do
    for j in 'txt' 'tsv' 'csv';do
        if [ ${j} == 'txt' ]; then
            echo 'AAA BBB CCC' > "./${dirname}/abc${i}.${j}"
        elif [ ${j} == 'tsv' ]; then
            echo "AAA\tBBB\tCCC" > "./${dirname}/abc${i}.${j}"
        elif [ ${j} == 'csv' ]; then
            echo 'AAA,BBB,CCC' > "./${dirname}/abc${i}.${j}"
        fi
    done
done
