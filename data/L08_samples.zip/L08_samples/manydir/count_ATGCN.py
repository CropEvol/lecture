import sys

args = sys.argv     # コマンドライン引数を取得
argc = len(args)   # 引数の個数

# 引数の個数が1以外の場合エラー出力
if argc-1 > 1:
    print('Error: too many arguments.')
elif argc-1 < 1:
    print('Error: no arguments')

# --------------------------------------

f = open(args[1], 'r')

NameList = []   # 配列名を保持するリスト
A_NUMS = []     # Aの個数を保持するリスト
T_NUMS = []     # Tの個数を保持するリスト
G_NUMS = []     # Gの個数を保持するリスト
C_NUMS = []     # Cの個数を保持するリスト
N_NUMS = []     # Nの個数を保持するリスト

SeqN = 0        # 配列番号

for line in f:                # 一行ずつ読み込む
    line = line[:-1]          # 改行文字を取り除く

    if line[0] == '>':        # 配列名の行のとき
        SeqN += 1             # 配列番号カウントアップ
        name = line[1:]       # 配列名を取得
        NameList.append(name) # 配列名をリストに追加

        if SeqN > 1:         # 個数カウンタの数値をリストに追加
            A_NUMS.append(As)
            T_NUMS.append(Ts)
            G_NUMS.append(Gs)
            C_NUMS.append(Cs)
            N_NUMS.append(Ns)

        As = 0
        Ts = 0
        Gs = 0
        Cs = 0
        Ns = 0

    else:                           # 塩基配列行のとき
        seq = line                  # 塩基配列の変数
        As += seq.count('A')
        Ts += seq.count('T')
        Gs += seq.count('G')
        Cs += seq.count('C')
        Ns += seq.count('N')

A_NUMS.append(As)
T_NUMS.append(Ts)
G_NUMS.append(Gs)
C_NUMS.append(Cs)
N_NUMS.append(Ns)

f.close()    # ファイルを閉じる

for i in range(SeqN):
    print(
        '%s\t%d\t%d\t%d\t%d\t%d' % (
            NameList[i],
            A_NUMS[i],
            T_NUMS[i],
            G_NUMS[i],
            C_NUMS[i],
            N_NUMS[i]
        )
    )
