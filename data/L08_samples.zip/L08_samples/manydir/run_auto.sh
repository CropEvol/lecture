cat /dev/null > result01.txt    # 空の出力ファイルを作成

# 1から50の数字を順に発生させ、iという変数に入れる
for i in {1..50};do
    j=`printf '%03d' $i`    # 数字が3桁になるよう、0埋め（ゼロパディング）する

    python count_ATGCN.py seq_${j}.fasta | tee -a result01.txt
    # 変数jに入っている0埋め後の数字を使い、FASTAファイル名を完成させる
    # Pythonプログラムの実行。結果をパイプで次のコマンドに渡す
    # teeコマンドでファイル書き込み（追加書き込みモード）＆画面出力を同時におこなう
done
